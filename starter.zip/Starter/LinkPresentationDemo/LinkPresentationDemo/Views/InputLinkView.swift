//
//  InputLinkView.swift
//  LinkPresentationDemo
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import SwiftUI

struct InputLinkView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var linksList: LinksModel
    @State private var link: String = ""
    
    var body: some View {
        VStack {
            // Top buttons.
            HStack {
                Button(action: {
                    self.presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "xmark.circle")
                        .font(.title).foregroundColor(.gray)
                }
                
                Spacer()
                
                Button(action: {
                    // Save link metadata.
                }) {
                    Image(systemName: "checkmark.circle")
                        .font(.title).foregroundColor(.gray)
                }
            }
            .padding(20)
            
            
            // Text field.
            TextField("Type or paste a link...", text: $link, onEditingChanged: { (changed) in
                // Clear previous metadata.
            }) {
                // Fetch link metadata.
            }
                .font(.title)
                .multilineTextAlignment(.center)
                .keyboardType(.URL)
                .disableAutocorrection(true)
                .autocapitalization(.none)
                .padding(.horizontal, 8)
                .padding(.top, 20)
            
            
            Spacer()
            
            // Link preview.
            HStack {
                if false {
                    EmptyView()
                } else {
                    Text("Link preview will be shown here")
                        .font(.title)
                        .fontWeight(.thin)
                        .multilineTextAlignment(.center)
                        .foregroundColor(Color.init(white: 0.4))
                }
            }
                .padding(20)
            
            Spacer()
            
        }
    }
}

struct InputLinkView_Previews: PreviewProvider {
    static var previews: some View {
        InputLinkView()
    }
}
