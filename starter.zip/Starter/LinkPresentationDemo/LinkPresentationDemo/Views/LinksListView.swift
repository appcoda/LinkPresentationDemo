//
//  LinksListView.swift
//  LinkPresentationDemo
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2020 AppCoda. All rights reserved.
//

import SwiftUI

struct LinksListView: View {
    @EnvironmentObject var linksList: LinksModel
    @State private var showInputLinkView = false
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Links will appear here")
                
                EmptyView()
            }
            .navigationBarTitle("Links")
            .navigationBarItems( trailing:
                Button(action: {
                    self.showInputLinkView = true
                }) {
                    Image(systemName: "plus.circle")
                        .font(.title)
                }
                .sheet(isPresented: self.$showInputLinkView) {
                    InputLinkView()
                        .environmentObject(self.linksList)
                }
            )
        }
    }
}

struct LinksListView_Previews: PreviewProvider {
    static var previews: some View {
        LinksListView().environmentObject(LinksModel())
    }
}
